import React, { useState } from 'react';
import './App.css'; // 👈 Make sure this file exists

function App() {
  const [emailText, setEmailText] = useState('');
  const [replyText, setReplyText] = useState('');
  const [tone, setTone] = useState('Professional');
  const [loading, setLoading] = useState(false);

  const handleGenerateReply = async () => {
    if (!emailText.trim()) return;

    setLoading(true);
    try {
      const response = await fetch('http://localhost:5000/api/email/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          emailContent: emailText,
          tone: tone,
        }),
      });

      const data = await response.json();
      setReplyText(data.reply || 'No reply received.');
    } catch (err) {
      setReplyText('❌ Error generating reply.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <h1 className="heading">📧 AI Email Reply Generator</h1>

      <label className="label">🎯 Select Reply Tone:</label>
      <select
        value={tone}
        onChange={(e) => setTone(e.target.value)}
        className="select"
      >
        <option value="Professional">Professional</option>
        <option value="Friendly">Friendly</option>
        <option value="Polite">Polite</option>
        <option value="Concise">Concise</option>
        <option value="Formal">Formal</option>
      </select>

      <label className="label">📥 Input Email:</label>
      <textarea
        rows="10"
        placeholder="Paste the email here..."
        value={emailText}
        onChange={(e) => setEmailText(e.target.value)}
        className="textarea"
      />

      <button
        onClick={handleGenerateReply}
        disabled={loading}
        className="button"
      >
        {loading ? '🔄 Generating...' : '🚀 Generate Reply'}
      </button>

      {replyText && (
        <>
          <h3 className="subheading">📝 Suggested Reply:</h3>
          <pre className="replyBox">{replyText}</pre>
        </>
      )}
    </div>
  );
}

export default App;
